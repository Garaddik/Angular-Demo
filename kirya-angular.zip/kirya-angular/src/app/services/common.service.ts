import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable()
export class CommonService{

    constructor(private http: HttpClient) {

    }

    getData():Observable<any>{
        return this.http.get("")
    }
    postData(mode: any, data: any): Observable<any> {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json');
        return this.http.post("URL"+ "Org/SaveOrgData?mode=" + mode, data,{headers:headers});
    }
}